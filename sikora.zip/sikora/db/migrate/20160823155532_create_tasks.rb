class CreateTasks < ActiveRecord::Migration
  def change
    create_table :tasks do |t|
      t.references :member, index: true, foreign_key: true
      t.references :tasktype, index: true, foreign_key: true
      t.text :description

      t.timestamps null: false
    end
  end
end
