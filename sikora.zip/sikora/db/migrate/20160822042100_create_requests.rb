class CreateRequests < ActiveRecord::Migration
  def change
    create_table :requests do |t|
      t.references :user, index: true, foreign_key: true
      t.references :team, index: true, foreign_key: true
      t.integer :owner
      t.integer :condition, default: '3' # 1:aprovada, 2:reporvada, 3:pendente

      t.timestamps null: false
    end
  end
end
