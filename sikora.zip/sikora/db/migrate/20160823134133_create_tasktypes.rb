class CreateTasktypes < ActiveRecord::Migration
  def change
    create_table :tasktypes do |t|
      t.string :name

      t.timestamps null: false
    end
  end
end
