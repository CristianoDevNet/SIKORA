require 'rails_helper'

RSpec.describe Team, type: :model do
	context "Validade do time" do
		it "time válido?" do
			team = Team.new
			team.name = "teste"

			expect(team.valid?).to be_truthy
		end

		it "time inválido? (nil)" do
			team = Team.new
			team.name = nil

			expect(team.valid?).to be_falsey
		end

		it "time inválido? (empty string)" do
			team = Team.new
			team.name = '  '

			expect(team.valid?).to be_falsey
		end
	end
end