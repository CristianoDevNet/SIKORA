class TeamsController < ApplicationController
  before_action :set_team, only: [:show, :edit, :update, :destroy]

  # ############################################################################# comentar depois
  before_action :set_task, only: [:show]

  # Impedimos aqui a visualização de algumas páginas caso o usuário não esteja logado
  before_action :is_logged_user, only: [:show, :edit, :update, :destroy]

  # GET /teams
  # GET /teams.json
  def index
    # a index serve resultados para as views de acordo com o status da sessão
    # @availableteams pode ser:
    #   -todos os times (se ninguém estiver logado) ou
    #   -somente os times que o usuário ainda não entrou
    # @addedteams são os times que o usuário entrou
    # @createdteams são os times que o usuário criou
    if current_user.present?
      # Selecione todos os times e que o usuário não participa
      @availableteams = Team.where.not(:id => Member.where(:user_id => current_user.id).pluck(:team_id))

      # Selecione todos os times que o usuário participa mas que não criou
      @addedteams = Team.joins(:members).where('members.user_id = ? and members.is_admin = ?', current_user.id, false)

      # Selecione todos os times riados pelo usuário
      @createdteams = Team.joins(:members).where('members.user_id = ? and members.is_admin = ?', current_user.id, true)

      # Precisamos verificar se existem pedidos de ingresso para os teams que o usuário amdinistra
      # e, caso afirmativo(se a variável @requests contiver registros), disponibilizar um link para aprovação ou revogação
      # dos pedidos, na parte superior da página
      @requests = Request.where('owner = ? and condition = ?', current_user.id, '3')
    else
      @availableteams = Team.all
    end
  end

  # GET /teams/1
  # GET /teams/1.json
  def show
    # O método show configura uma variável chamada @teamaction que indicará o tipo
    # de html renderizado pela view, levando em conta a relação do usuário logado com o team
    # Esta relação é a presente(ou não) na tabela members
    @member = Member.where('user_id = ? and team_id = ?', current_user.id, params[:id]).first

    # Tradicionalmente a inserção de dados de um respectivo model é feito no seu controle
    # aqui fazemos um pouco diferente, como as tasks do usuário são exibidas a partir do controller de team
    # carregamos as tasks do usuário na variável @usertasks para exibirmos no formulário show(de team)
    if @member != nil
      # "Time.zone.now.beginning_of_day" traz apenas os registros postados hoje
      @usertasks = Task.includes(:tasktype).where('member_id = ? and created_at >= ?', @member.id, Time.zone.now.beginning_of_day).order('tasktype_id')

    end
    
    @teammembers = Task.joins(:tasktype, {member: :user}).where('members.is_admin == ? and tasks.created_at >= ? and members.team_id = ?', false, Time.zone.now.beginning_of_day, params[:id]).order(['users.name ASC', 'tasktypes.id DESC'])
  end

  # GET /teams/new
  def new
    if current_user.present?
      @team = Team.new
    else
      redirect_to new_user_session_path
    end
  end

  # GET /teams/1/edit
  def edit
  end

  # POST /teams
  # POST /teams.json
  def create
    @team = Team.new(team_params)

    if @team.name == ''
      flash.now.notice = 'The "name" field cannot be empty.'
      
      respond_to do |format|
        format.html { render :new }
      end
    else
      @user = User.find(current_user.id)

      @member = Member.new

      @member.team = @team

      @member.user = @user

      @member.is_admin = true

      respond_to do |format|
        if @member.save
          format.html { redirect_to teams_path, notice: 'Team was successfully created.' }
          format.json { render :show, status: :created, location: @team }
        else
          format.html { render :new }
          format.json { render json: @team.errors, status: :unprocessable_entity }
        end
      end
    end
  end

  # PATCH/PUT /teams/1
  # PATCH/PUT /teams/1.json
  def update
    respond_to do |format|
      if @team.update(team_params)
        format.html { redirect_to @team, notice: 'Team was successfully updated.' }
        format.json { render :show, status: :ok, location: @team }
      else
        format.html { render :edit }
        format.json { render json: @team.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /teams/1
  # DELETE /teams/1.json
  def destroy
    @team.destroy
    respond_to do |format|
      format.html { redirect_to teams_url, notice: 'Team was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def add_task
    if params[:task][:description] == ''
      flash.notice = 'The "description" field cannot be empty.'

      respond_to do |format|
        # format.html { render :show }
        format.html { redirect_to :back }
      end
    else
      @task = Task.new

      @task.description = params[:task][:description]

      @task.member_id = params[:task][:idmember]

      @task.tasktype_id = params[:task][:tasktype]

      # Após salvar, redireciona para a mesma página
      @task.save

      redirect_to :back
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_team
      @team = Team.find(params[:id])
    end

    def set_task
      @task = Task.new
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def team_params
      params.require(:team).permit(:name, :description)
    end

    # Se o usuário não estiver logado, redireciona para a página inicial
    def is_logged_user
      if !current_user.present?
        redirect_to teams_path
      end
    end
end
