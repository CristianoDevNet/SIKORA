class RequestsController < ApplicationController
	# Impedimos aqui a visualização de algumas páginas caso o usuário não esteja logado
  	before_action :is_logged_user, only: [:show]

  	def index
  		@requests = Request.where('owner = ? and condition = ?', current_user.id, '3')
  	end

	def new
	    req = Request.new
	    req.user_id = current_user.id
	    req.team_id = params[:teamid]
	    req.owner = Member.find(params[:teamid]).user_id

	    respond_to do |format|
	      if req.save
	        format.html { redirect_to teams_path, notice: 'Inclusion request successfully sent.' }
	      else
	        format.html { render :new }
	      end
	    end
  	end

  	def request_action
  		# O dono do team pode confimar a solitação(1) ou negar(2)
  		# Se o parâmeto recebi do GET for um desses dois, a operação de update é efetuada
  		if ['1', '2'].include? params[:confirm]
  			Request.update(params[:requestid], :condition => params[:confirm])

  			# Se a solicitação foi aprovada, adicionamos o usuário no team
  			if params[:confirm] == '1'
  				@member = Member.new
  				@member.user_id = params[:userid]
  				@member.team_id = params[:teamid]
  				@member.is_admin = false
  				@member.save
  			end

  			redirect_to teams_path
  		end
  	end
  	# Se o usuário não estiver logado, redireciona para a página inicial
    def is_logged_user
      if !current_user.present?
        redirect_to teams_path
      end
    end
end
