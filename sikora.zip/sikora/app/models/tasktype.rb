class Tasktype < ActiveRecord::Base
end
