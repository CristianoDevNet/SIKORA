class Team < ActiveRecord::Base

	has_many :members
	has_many :users, through: :members
	has_many :requests
	has_many :users, through: :requests

	validates :name, presence: true
end
