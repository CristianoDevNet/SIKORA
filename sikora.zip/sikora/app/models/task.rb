class Task < ActiveRecord::Base
  	belongs_to :member
  	belongs_to :tasktype
end
